#!/bin/bash

sleep $(shuf -i 6-500 -n 1)
cd /root/sp/js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_dreamFactory.js -O /root/sp/js/jd_dreamFactory.js
#sed -i "s/turinglabs/xxxx/g" jd_dreamFactory.js
sed -i "s#http://api.turinglabs.net/api/v1/jd/jxfactory/read/\${randomCount\}/#https\://raw.githubusercontent.com/ktownag/JDtmp/main/dreamFactory\.json#" jd_dreamFactory.js
#删除 const inviteCodes = ['V5LkjP4WRyjeCKR9VRwcRX0bBuTz7MEK0-E99EJ7u0k=', 'PDPM257r_KuQhil2Y7koNw==', "gB99tYLjvPcEFloDgamoBw=="];
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" jd_dreamFactory.js

#替换https://raw.githubusercontent.com/lxk0301/updateTeam/master/jd_updateFactoryTuanId.json
#为https://raw.githubusercontent.com/ktownag/JDtmp/main/jd_updateFactoryTuanId.json
#内容：{"tuanActiveId":"hKG99U5VUBy62dlrIo8_Jw==","tuanIds":[]}
sed -i "s/lxk0301\/updateTeam\/master/ktownag\/JDtmp\/main/" jd_dreamFactory.js


acc=($(shuf -e "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_dreamFactory.js $i_dreamFactory.js
  printf "\n$(date) 正在运行  ${i}_dreamFactory.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/$i'/" $i_dreamFactory.js
  node $i_dreamFactory.js
  rm $i_dreamFactory.js
done
