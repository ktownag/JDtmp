#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_cash.js -O /root/sp/js/jd_cash.js
#sleep $(shuf -i 8-400 -n 1)
cd /root/sp/js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  printf "\n$(date) 正在运行  ${i}_cash.js\n"
  sed -e "s/turinglabs/xxxx/g;
    s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/;
    s/chiang.fun/xxxxxx/g;
    s/updateTeam/xxxxxx/g;
     /^let shareCodes = /,/^]$/c\let shareCodes = ['']; 
      /^const inviteCodes = /,/^]$/c\const inviteCodes = [\`\`,\n\`\`\n]" jd_cash.js | node
#  sleep $(shuf -i 1-9 -n 1)
done
