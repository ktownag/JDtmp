#!/bin/bash
#node ba_unsubscribe.js
node ba_superMarket.js
node ba_speed.js
node ba_plantBean.js
node ba_pet.js
node ba_moneyTree.js
node ba_joy_steal.js
node ba_joy_reward.js
node ba_joy_feedPets.js
node ba_joy.js
node ba_fruit.js
node ba_blueCoin.js
