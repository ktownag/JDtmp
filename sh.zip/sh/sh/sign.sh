#!/bin/bash

cd /root/sp/js
acc=("ma" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "sha")
sed -i "s/var out = 5000/var out = 0/" JD_DailyBonus.js
sed -i "s/var stop = 0/var stop = 6866/" JD_DailyBonus.js 

for ((i=0;i<4;i++));
do
  # echo ${#acc[i]}
  a=${acc[i]}
  b=${acc[i+4]}
  c=$(cat ../cki/${acc[i]}.js)
  #e="$c | $(cut -d "'" -f2) | $(tr -d '\n')"
  e=$(cat /root/sp/cki/${a}.js | cut -d "'" -f2 | tr -d '\n')
  f=$(cat /root/sp/cki/${b}.js | cut -d "'" -f2 | tr -d '\n')
  printf "\n$(date) 正在运行  $a 和 $b 签到\n"
  cp JD_DailyBonus.js JD_DailyBonus_${i}.js
  echo "{"CookieJD":"$e","CookieJD2":"$f"}" > CookieSet.json
  ls JD_DailyBonus_${i}.js
  #sleep $(shuf -i 8-40 -n 1)
done
