#!/bin/bash
wget https://raw.githubusercontent.com/whyour/hundun/master/quanx/jx_story.js -O /root/sp/js/jx_story.js
#wget https://raw.githubusercontent.com/MoPoQAQ/Script/main/Me/jx_story.js -O /root/sp/js/jx_story.js
#wget https://gitee.com/lxk0301/jd_scripts/raw/master/jx_story.js -O /root/sp/js/jx_story.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
#sed -i "s/turinglabs/xxxx/g" jx_story.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" jx_story.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jx_story.js ${i}_story.js
  printf "\n$(date) 正在运行  ${i}_story.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_story.js
  node ${i}_story.js
  rm ${i}_story.js
done
