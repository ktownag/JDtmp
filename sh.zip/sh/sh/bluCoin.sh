#! /bin/bash
sleep $(shuf -i 10-200 -n 1)
acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
cd /root/sp/js

sed -i "/^let coinToBeans = /clet coinToBeans = \$.getdata('coinToBeans') * 1 || 20;"  jd_blueCoin.js

runjs() {
  for i in ${acc[@]}
  do
    cp jd_blueCoin.js ${i}_blueCoin.js
    printf "\n$(date) 正在运行  ${i}_blueCoin.js\n"
    sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_blueCoin.js
    node ${i}_blueCoin.js
    rm ${i}_blueCoin.js
  done
  }

runjs
