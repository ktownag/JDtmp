#!/bin/bash
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js

cp jd_superMarket.js sha_superMarket.js
cp jd_superMarket.js ales33_superMarket.js
cp jd_superMarket.js ales1_superMarket.js
cp jd_superMarket.js ba_superMarket.js
cp jd_superMarket.js qiu_superMarket.js
cp jd_superMarket.js ma_superMarket.js

printf "\n$(date) 正在运行  sha_superMarket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/sha'/" sha_superMarket.js
node sha_superMarket.js

printf "\n$(date) 正在运行  ales33_superMarket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales33'/" ales33_superMarket.js
node ales33_superMarket.js

printf "\n$(date) 正在运行  ales1_superMarket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales1'/" ales1_superMarket.js
node ales1_superMarket.js

printf "\n$(date) 正在运行  ba_superMarket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ba'/" ba_superMarket.js
node ba_superMarket.js

printf "\n$(date) 正在运行  qiu_superMarket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/qiu'/" qiu_superMarket.js
node qiu_superMarket.js

printf "\n$(date) 正在运行  ma_superMarket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ma'/" ma_superMarket.js
node ma_superMarket.js

