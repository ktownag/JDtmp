#!/bin/bash
cd /root/sp/sh
js=($(shuf -e "jdzz" "jdSign" "health" "car" "kd" "wo" "necklace" "redPacket"))
for j in ${js[@]}
do
  bash ../sh/${j}.sh
done
