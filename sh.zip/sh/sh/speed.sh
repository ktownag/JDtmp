#!/bin/bash
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_speed.js $i_speed.js
  printf "\n$(date) 正在运行  ${i}_speed.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/$i'/" $i_speed.js
  node $i_speed.js
  rm $i_speed.js
done

acc2=($(shuf -e "ba" "qiu"))
for i in ${acc2[@]}
do
  cp jd_daily_egg.js $i_daily_egg.js
  printf "\n$(date) 正在运行  ${i}_daily_egg.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/$i'/" $i_daily_egg.js
  node $i_daily_egg.js
  rm $i_daily_egg.js
done

bash ../sh/timeMachine.sh
