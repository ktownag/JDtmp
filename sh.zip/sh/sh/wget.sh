#!/bin/bash

wget https://raw.githubusercontent.com/Sunert/Scripts/master/Task/jingxi.js -O /root/sp/js/jingxi.js
wget https://raw.githubusercontent.com/yangtingxiao/QuantumultX/master/scripts/jd/jd_baiTiao.js -O /root/sp/js/jd_baiTiao.js
#wget https://raw.githubusercontent.com/yangtingxiao/QuantumultX/master/scripts/jd/jd_bigWinner.js -O /root/sp/js/jd_bigWinner.js
#wget https://raw.githubusercontent.com/yangtingxiao/QuantumultX/master/scripts/jd/jd_rankingList.js -O /root/sp/js/jd_rankingList.js
#wget https://raw.githubusercontent.com/yangtingxiao/QuantumultX/master/scripts/jd/jd_timeMachine.js -O /root/sp/js/jd_timeMachine.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_lotteryMachine.js -O /root/sp/js/jd_lotteryMachine.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_daily_egg.js -O /root/sp/js/jd_daily_egg.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_fruit.js -O /root/sp/js/jd_fruit.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_pet.js -O /root/sp/js/jd_pet.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_joy.js -O /root/sp/js/jd_joy.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_joy_reward.js -O /root/sp/js/jd_joy_reward.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_plantBean.js -O /root/sp/js/jd_plantBean.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_moneyTree.js -O /root/sp/js/jd_moneyTree.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_speed.js -O /root/sp/js/jd_speed.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_unsubscribe.js -O /root/sp/js/jd_unsubscribe.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_joy.js -O /root/sp/js/jd_joy.js

wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_blueCoin.js -O /root/sp/js/jd_blueCoin.js
cp /root/sp/js/jd_blueCoin.js /root/logjd
sed -i "/^let coinToBeans = /clet coinToBeans = \$.getdata('coinToBeans') * 1 || 1000;" /root/logjd/jd_blueCoin.js

wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_superMarket.js -O /root/sp/js/jd_superMarket.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_joy_steal.js -O /root/sp/js/jd_joy_steal.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_joy_feedPets.js -O /root/sp/js/jd_joy_feedPets.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_shop.js -O /root/sp/js/jd_shop.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_club_lottery.js -O /root/sp/js/jd_club_lottery.js
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_redPacket.js -O /root/sp/js/jd_redPacket.js
wget https://raw.githubusercontent.com/NobyDa/Script/master/JD-DailyBonus/JD_DailyBonus.js -O /root/sp/js/JD_DailyBonus.js
sed -i "s/ 10\;\/\// 100\;\/\//" /root/sp/js/jd_unsubscribe.js
sed -i "s/jdUnsubscribePageSize') || 0;/jdUnsubscribePageSize\'\) || 50;/g" /root/sp/js/jd_unsubscribe.js
printf "$(date) wget.js 已完成\n"
