#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_jdzz.js -O /root/sp/js/jdzz.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jdzz.js
sed -i "s/code.chiang.fun/deld/g" jdzz.js
sed -i "/^const inviteCodes = /,/^]$/c\const inviteCodes = [\n  \`SvPRwSBob9VTQPRP9k_IIdg@S5KkcRBgYoAaGIUnxlvEKJw@S76EmAx0a@S5KkcRUxL9QDeJBilkaYDcQ@St_2m5L7Nee4Bobo\`\n\n];" jdzz.js
sed -i "s/jd_zz.json/deld/g" jdzz.js
acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jdzz.js ${i}_jdzz.js
  printf "\n$(date) 正在运行  ${i}_jdzz.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_jdzz.js
  node ${i}_jdzz.js
  rm ${i}_jdzz.js
done
