#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_redPacket.js -O /root/sp/js/jd_redPacket.js
sleep $(shuf -i 8-400 -n 1)
#test ales33
cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jd_redPacket.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" jd_redPacket.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_redPacket.js ${i}_redPacket.js
  printf "\n$(date) 正在运行  ${i}_redPacket.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_redPacket.js
  node ${i}_redPacket.js
  rm ${i}_redPacket.js
done
