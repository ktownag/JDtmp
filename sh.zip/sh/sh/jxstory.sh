#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/activity/jd_jxstory.js -O /root/sp/js/activity/jd_jxstory.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js/activity
sed -i "s/turinglabs/xxxx/g" jd_jxstory.js
sed -i "/ inviteCodes = \[/c\const inviteCodes = [\'\'];" jd_jxstory.js
acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_jxstory.js $i_jxstory.js
  printf "\n$(date) 正在运行  ${i}_jxstory.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/$i'/" $i_jxstory.js
  node $i_jxstory.js
  rm $i_jxstory.js
done
