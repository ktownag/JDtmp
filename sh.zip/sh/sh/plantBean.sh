#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_plantBean.js -O /root/sp/js/jd_plantBean.js
sleep $(shuf -i 8-400 -n 1)
cd /root/sp/js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  printf "\n$(date) 正在运行  ${i}_plantBean.js\n"
  sed -e "s/turinglabs/xxxx/g;
   s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/;
    /^let shareCodes = /,/^]$/c\let shareCodes = [''];" jd_plantBean.js | node
  sleep $(shuf -i 1-9 -n 1)
done
