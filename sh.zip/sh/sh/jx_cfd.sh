#!/bin/bash
wget https://raw.githubusercontent.com/MoPoQAQ/Script/main/Me/jx_cfd.js -O /root/sp/js/jx_cfd.js
#wget https://gitee.com/lxk0301/jd_scripts/raw/master/jx_cfd.js -O /root/sp/js/jx_cfd.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jx_cfd.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" jx_cfd.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jx_cfd.js ${i}_cfd.js
  printf "\n$(date) 正在运行  ${i}_cfd.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_cfd.js
  node ${i}_cfd.js
  rm ${i}_cfd.js
done
