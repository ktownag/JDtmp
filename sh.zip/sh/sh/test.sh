#! /bin/bash
accr=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${accr[@]}
do
  cp jingxi.js $i_jingxi.js
  printf "\n$(date) 正在运行  ${i}_jingxi.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/$i'/" $i_jingxi.js
  node $i_jingxi.js
  rm $i_jingxi.js
  sleep $(shuf -i 8-40 -n 1)
done

