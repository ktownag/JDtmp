#!/bin/bash
wget https://raw.githubusercontent.com/whyour/hundun/master/quanx/dd_factory.js -O /root/sp/js/dd_factory.js

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" dd_factory.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" dd_factory.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp dd_factory.js ${i}_dd_factory.js
  printf "\n$(date) 正在运行  ${i}_dd_factory.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_dd_factory.js
  node ${i}_dd_factory.js
  rm ${i}_dd_factory.js
done
