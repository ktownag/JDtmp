#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_bean_home.js -O /root/sp/js/jd_bean_home.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jd_bean_home.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" jd_bean_home.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_bean_home.js ${i}_bean_home.js
  printf "\n$(date) 正在运行  ${i}_bean_home.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_bean_home.js
  node ${i}_bean_home.js
  rm ${i}_bean_home.js
done
