#!/bin/bash
wget https://cdn.jsdelivr.net/gh/yangtingxiao/QuantumultX@master/scripts/jd/jd_lotteryMachine.js -O /root/sp/js/jd_lotteryMachine.js
sleep $(shuf -i 8-400 -n 1)
sed -i "/^const shareCodeArr = /c\const shareCodeArr = [''];" jd_lotteryMachine.js
sed -i "s/inviteId=.*\`/inviteId=\`/g" jd_lotteryMachine.js
cd /root/sp/js
acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_lotteryMachine.js ${i}_lotteryMachine.js
  printf "\n$(date) 正在运行  ${i}_lotteryMachine.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_lotteryMachine.js
  node ${i}_lotteryMachine.js
  rm ${i}_lotteryMachine.js
done

bash ../sh/rankingList.sh
