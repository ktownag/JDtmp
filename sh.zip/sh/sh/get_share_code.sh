#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_get_share_code.js -O /root/sp/js/jd_get_share_code.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jd_get_share_code.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" jd_get_share_code.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_get_share_code.js ${i}_get_share_code.js
  printf "\n$(date) 正在运行  ${i}_get_share_code.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_get_share_code.js
  node ${i}_get_share_code.js
  rm ${i}_get_share_code.js
done
