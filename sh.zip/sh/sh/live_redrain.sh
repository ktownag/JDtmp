#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/activity/jd_live_redrain2.js -O /root/sp/js/activity/jd_live_redrain.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js/activity
sed -i "s/turinglabs/xxxx/g" jd_live_redrain.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_live_redrain.js $i_live_redrain.js
  printf "\n$(date) 正在运行  ${i}_live_redrain.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/$i'/" $i_live_redrain.js
  node $i_live_redrain.js
  rm $i_live_redrain.js
done
