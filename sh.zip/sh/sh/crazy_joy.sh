#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_crazy_joy.js -O /root/sp/js/jd_crazy_joy.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jd_crazy_joy.js
sed -i "s/chiang.fun/xxxxxx/g" jd_crazy_joy.js
sed -i "/^const inviteCodes = /,/^];$/c\const inviteCodes = ['i9l1BpBxnOTLLmgu2I_e4A==@VI3y4E5rWQ8JVP2k5KIo36t9zd5YaBeE@n1jxi5IBx8aLIzyYQ9EUWat9zd5YaBeE@DcP8hX2o_zss8fuRHm8it6t9zd5YaBeE@wjpaRYiKMDc='];" jd_crazy_joy.js
sed -i "/nextCode = \[/c\  $.nextCode = [\"\"];" jd_crazy_joy.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_crazy_joy.js ${i}_crazy_joy.js
  printf "\n$(date) 正在运行  ${i}_crazy_joy.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_crazy_joy.js
  node ${i}_crazy_joy.js
  rm ${i}_crazy_joy.js
done
