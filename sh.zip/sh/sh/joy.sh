#!/bin/bash
sleep $(shuf -i 8-400 -n 1)
cd /root/sp/js

cp jd_joy.js sha_joy.js
cp jd_joy.js ales33_joy.js
cp jd_joy.js ales1_joy.js
cp jd_joy.js ba_joy.js
cp jd_joy.js qiu_joy.js
cp jd_joy.js ma_joy.js

printf "\n$(date) 正在运行  sha_joy.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/sha'/" sha_joy.js
node sha_joy.js

printf "\n$(date) 正在运行  ales33_joy.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales33'/" ales33_joy.js
node ales33_joy.js

printf "\n$(date) 正在运行  ales1_joy.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales1'/" ales1_joy.js
node ales1_joy.js

printf "\n$(date) 正在运行  ba_joy.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ba'/" ba_joy.js
node ba_joy.js

printf "\n$(date) 正在运行  qiu_joy.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/qiu'/" qiu_joy.js
node qiu_joy.js

printf "\n$(date) 正在运行  ma_joy.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ma'/" ma_joy.js
node ma_joy.js

