#!/bin/bash
cd /root/sp/sh

bash ../sh/bean_home.sh
#bash ../sh/ms_redrain.sh
bash ../sh/syj.sh
bash ../sh/crazy_joy.sh
bash ../sh/crazy_joy_coin.sh
