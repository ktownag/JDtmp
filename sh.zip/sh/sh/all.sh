#!/bin/sh

bash /root/sp/sh/fruit-ales1.sh
bash /root/sp/sh/joy_feedPets.sh
bash /root/sp/sh/money_Tree.sh
bash /root/sp/sh/bluCoin.sh
bash /root/sp/sh/fruit.sh
bash /root/sp/sh/joy_reward.sh
bash /root/sp/sh/818.sh
bash /root/sp/sh/joy.sh
bash /root/sp/sh/joy_feedPets.sh

bash /root/sp/sh/joy_steal.sh

bash /root/sp/sh/pet.sh
bash /root/sp/sh/speed.sh
bash /root/sp/sh/superMarket.sh
