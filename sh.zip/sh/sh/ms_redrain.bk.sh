#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_ms_redrain.js -O /root/sp/js/jd_ms_redrain.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jd_ms_redrain.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" jd_ms_redrain.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_ms_redrain.js ${i}_ms_redrain.js
  printf "\n$(date) 正在运行  ${i}_ms_redrain.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_ms_redrain.js
  node ${i}_ms_redrain.js
  rm ${i}_ms_redrain.js
done
