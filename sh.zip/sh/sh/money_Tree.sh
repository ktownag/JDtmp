#!/bin/bash

sleep $[ ( $RANDOM % 10 )  + 1 ]s
cd /root/sp/js

cp jd_moneyTree.js sha_moneyTree.js
cp jd_moneyTree.js ales33_moneyTree.js
#cp jd_moneyTree.js ales1_moneyTree.js
cp jd_moneyTree.js ba_moneyTree.js
cp jd_moneyTree.js qiu_moneyTree.js
cp jd_moneyTree.js ma_moneyTree.js

printf "\n$(date) 正在运行  sha_moneyTree.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/sha'/" sha_moneyTree.js
node sha_moneyTree.js

printf "\n$(date) 正在运行  ales33_moneyTree.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales33'/" ales33_moneyTree.js
node ales33_moneyTree.js

#printf "\n$(date) 正在运行  ales1_moneyTree.js\n"
#sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales1'/" ales1_moneyTree.js
#node ales1_moneyTree.js

printf "\n$(date) 正在运行  ba_moneyTree.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ba'/" ba_moneyTree.js
node ba_moneyTree.js

printf "\n$(date) 正在运行  qiu_moneyTree.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/qiu'/" qiu_moneyTree.js
node qiu_moneyTree.js

printf "\n$(date) 正在运行  ma_moneyTree.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ma'/" ma_moneyTree.js
node ma_moneyTree.js


