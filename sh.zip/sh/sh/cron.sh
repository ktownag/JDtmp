#! /bin/bash
bash /root/sp/sh/$1.sh > /root/logjd/$1.txt 2>&1
#date > /root/logjd/$1.txt 2>&1
rclone move /root/logjd/$1.txt n:ali/log
