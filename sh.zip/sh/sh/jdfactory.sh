#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_jdfactory.js -O /root/sp/js/jd_jdfactory.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jd_jdfactory.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [\`P04z54XCjVWnYaS5m9cZ2T-3CkYxA6i-McMfHg\`, 'P04z54XCjVWnYaS5jwI3cRYCfDwQ_ou', 'P04z54XCjVWnYaS5jcBC2j833xKki7MrhMR6cg', 'P04z54XCjVWnYaS5mRUXSP73g', 'P04z54XCjVWnYaS5m9cZ2Wqj3wenEa0Tk6CLX4', 'P04z54XCjVWnYaS5mRUXSP5'];" jd_jdfactory.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_jdfactory.js ${i}_jdfactory.js
  printf "\n$(date) 正在运行  ${i}_jdfactory.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_jdfactory.js
  node ${i}_jdfactory.js
  rm ${i}_jdfactory.js
done
