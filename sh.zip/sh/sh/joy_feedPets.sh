#!/bin/bash
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
acc=($(shuf -e "ma" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "sha"))

for i in ${acc[@]}
do
    cp jd_joy_feedPets.js ${i}_joy_feedPets.js
    printf "\n$(date) 正在运行  ${i}_joy_feedPets.js\n"
    sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_joy_feedPets.js
    node ${i}_joy_feedPets.js
    rm ${i}_joy_feedPets.js
  done
