#!/bin/bash
wget https://raw.githubusercontent.com/yangtingxiao/QuantumultX/master/scripts/jd/jd_woHome.js -O /root/sp/js/jd_woHome.js
#wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_woHome.js -O /root/sp/js/jd_woHome.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jd_woHome.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" jd_woHome.js
sed -i "s/woHomeShareCode/woHomeShareCodeDeld/g" jd_woHome.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_woHome.js ${i}_woHome.js
  printf "\n$(date) 正在运行  ${i}_woHome.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_woHome.js
  node ${i}_woHome.js
  rm ${i}_woHome.js
done
