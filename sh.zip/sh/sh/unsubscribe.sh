#!/bin/bash
sleep $(shuf -i 8-40 -n 1)

cd /root/sp/js
sed -i "s/|| 20;\/\/ /|| 100;\/\/ /" jd_unsubscribe.js
cp jd_unsubscribe.js sha_unsubscribe.js
cp jd_unsubscribe.js ales33_unsubscribe.js
cp jd_unsubscribe.js ales1_unsubscribe.js
cp jd_unsubscribe.js ba_unsubscribe.js
cp jd_unsubscribe.js qiu_unsubscribe.js
cp jd_unsubscribe.js ma_unsubscribe.js

printf "\n$(date) 正在运行  sha_unsubscribe.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/sha'/" sha_unsubscribe.js
node sha_unsubscribe.js

printf "\n$(date) 正在运行  ales33_unsubscribe.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales33'/" ales33_unsubscribe.js
node ales33_unsubscribe.js

printf "\n$(date) 正在运行  ales1_unsubscribe.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales1'/" ales1_unsubscribe.js
node ales1_unsubscribe.js

printf "\n$(date) 正在运行  ba_unsubscribe.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ba'/" ba_unsubscribe.js
node ba_unsubscribe.js

printf "\n$(date) 正在运行  qiu_unsubscribe.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/qiu'/" qiu_unsubscribe.js
node qiu_unsubscribe.js

printf "\n$(date) 正在运行  ma_unsubscribe.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ma'/" ma_unsubscribe.js
node ma_unsubscribe.js

