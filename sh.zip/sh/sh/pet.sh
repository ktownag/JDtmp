#!/bin/bash
sleep $(shuf -i 10-200 -n 1)
cd /root/sp/js
sed -i "s/turinglabs/turinglabsDel/g"  jd_pet.js
cp jd_pet.js sha_pet.js
cp jd_pet.js ales33_pet.js
cp jd_pet.js ales1_pet.js
cp jd_pet.js ba_pet.js
cp jd_pet.js qiu_pet.js
cp jd_pet.js ma_pet.js

#ales1
a0='MTAxODc2NTEzMjAwMDAwMDAyMzIyMzMyNQ=='
#ales33
a='MTAxODc2NTEzMDAwMDAwMDAyMzIzMDE4MQ=='
#sha
b='MTAxODc2NTEzNDAwMDAwMDAyOTQzNjQyMQ=='
#ba
c='MTAxODc2NTE0NzAwMDAwMDAyOTQzNjQ0MQ=='
#ma
d='MTAxODc2NTEzNDAwMDAwMDAyOTQzNjQ5Mw=='
#qiu
e='MTAxODc2NTEzNTAwMDAwMDAzMTkwNTQ1Nw=='
#sed -i "/^let PetShareCodes = /,/^]$/clet PetShareCodes = [ '$a',\n  '$c',\n  '$b',\n  '$e',\n  '$a0',\n]" jdPetShareCodes.js
printf "\n$(date) 正在运行  sha_pet.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/sha'/" sha_pet.js
node sha_pet.js

printf "\n$(date) 正在运行  ales33_pet.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales33'/" ales33_pet.js
node ales33_pet.js

printf "\n$(date) 正在运行  ales1_pet.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales1'/" ales1_pet.js
node ales1_pet.js

printf "\n$(date) 正在运行  ba_pet.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ba'/" ba_pet.js
node ba_pet.js

printf "\n$(date) 正在运行  qiu_pet.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/qiu'/" qiu_pet.js
node qiu_pet.js

printf "\n$(date) 正在运行  ma_pet.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ma'/" ma_pet.js
node ma_pet.js




