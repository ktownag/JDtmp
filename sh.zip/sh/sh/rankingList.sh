#!/bin/bash
wget https://cdn.jsdelivr.net/gh/yangtingxiao/QuantumultX@master/scripts/jd/jd_rankingList.js -O /root/sp/js/jd_rankingList.js
sleep $(shuf -i 8-400 -n 1)
sed -i "/^const shareCodeArr = /c\const shareCodeArr = [''];" jd_rankingList.js

cd /root/sp/js
acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_rankingList.js ${i}_rankingList.js
  printf "\n$(date) 正在运行  ${i}_rankingList.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_rankingList.js
  node ${i}_rankingList.js
  rm ${i}_rankingList.js
done
