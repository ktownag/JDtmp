#!/bin/bash
sleep $(shuf -i 10-400 -n 1)
cd /root/sp/js
sed -i "/^const joyRewardName = /cconst joyRewardName = \$.getdata('joyRewardName') || '-1';"  jd_joy_reward.js
cp jd_joy_reward.js sha_joy_reward.js
cp jd_joy_reward.js ales33_joy_reward.js
cp jd_joy_reward.js ales1_joy_reward.js
cp jd_joy_reward.js ba_joy_reward.js
cp jd_joy_reward.js qiu_joy_reward.js
cp jd_joy_reward.js ma_joy_reward.js

printf "\n$(date) 正在运行 sha_joy_reward.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/sha'/" sha_joy_reward.js
node sha_joy_reward.js

printf "\n$(date) 正在运行  ales33_joy_reward.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales33'/" ales33_joy_reward.js
node ales33_joy_reward.js

printf "\n$(date) 正在运行  ales1_joy_reward.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales1'/" ales1_joy_reward.js
node ales1_joy_reward.js

printf "\n$(date) 正在运行  ba_joy_reward.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ba'/" ba_joy_reward.js
node ba_joy_reward.js

printf "\n$(date) 正在运行  qiu_joy_reward.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/qiu'/" qiu_joy_reward.js
node qiu_joy_reward.js

printf "\n$(date) 正在运行  ma_joy_reward.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ma'/" ma_joy_reward.js
node ma_joy_reward.js

