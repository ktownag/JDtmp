#!/bin/bash
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
acc=($(shuf -e "ba" "qiu"))
for i in ${acc[@]}
do
  cp jd_baiTiao.js $i_baiTiao.js
  printf "\n$(date) 正在运行  ${i}_baiTiao.js\n"
  cp cki/$i jdCookie.js
  node $i_baiTiao.js
  rm $i_baiTiao.js
done
