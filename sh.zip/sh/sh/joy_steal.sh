#!/bin/bash
sleep $(shuf -i 8-400 -n 1)
cd /root/sp/js

cp jd_joy_steal.js sha_joy_steal.js
cp jd_joy_steal.js ales33_joy_steal.js
cp jd_joy_steal.js ales1_joy_steal.js
cp jd_joy_steal.js ba_joy_steal.js
cp jd_joy_steal.js qiu_joy_steal.js
cp jd_joy_steal.js ma_joy_steal.js

printf "\n$(date) 正在运行  sha_joy_steal.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/sha'/" sha_joy_steal.js
node sha_joy_steal.js

printf "\n$(date) 正在运行  ales33_joy_steal.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales33'/" ales33_joy_steal.js
node ales33_joy_steal.js

printf "\n$(date) 正在运行  ales1_joy_steal.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales1'/" ales1_joy_steal.js
node ales1_joy_steal.js

printf "\n$(date) 正在运行  ba_joy_steal.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ba'/" ba_joy_steal.js
node ba_joy_steal.js

printf "\n$(date) 正在运行  qiu_joy_steal.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/qiu'/" qiu_joy_steal.js
node qiu_joy_steal.js

printf "\n$(date) 正在运行  ma_joy_steal.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ma'/" ma_joy_steal.js
node ma_joy_steal.js

