#!/bin/bash
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js

cp jd_shop.js sha_shop.js
cp jd_shop.js ales33_shop.js
cp jd_shop.js ales1_shop.js
cp jd_shop.js ba_shop.js
cp jd_shop.js qiu_shop.js
cp jd_shop.js ma_shop.js

printf "\n$(date) 正在运行  sha_shop.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/sha'/" sha_shop.js
node sha_shop.js

printf "\n$(date) 正在运行  ales33_shop.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales33'/" ales33_shop.js
node ales33_shop.js

printf "\n$(date) 正在运行  ales1_shop.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales1'/" ales1_shop.js
node ales1_shop.js

printf "\n$(date) 正在运行  ba_shop.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ba'/" ba_shop.js
node ba_shop.js

printf "\n$(date) 正在运行  qiu_shop.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/qiu'/" qiu_shop.js
node qiu_shop.js

printf "\n$(date) 正在运行  ma_shop.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ma'/" ma_shop.js
node ma_shop.js

rm `ls *_shop.js | grep -v jd_shop.js`

###

cp jd_club_lottery.js sha_club_lottery.js
cp jd_club_lottery.js ales33_club_lottery.js
cp jd_club_lottery.js ales1_club_lottery.js
cp jd_club_lottery.js ba_club_lottery.js
cp jd_club_lottery.js qiu_club_lottery.js
cp jd_club_lottery.js ma_club_lottery.js

printf "\n$(date) 正在运行  sha_club_lottery.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/sha'/" sha_club_lottery.js
node sha_club_lottery.js

printf "\n$(date) 正在运行  ales33_club_lottery.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales33'/" ales33_club_lottery.js
node ales33_club_lottery.js

printf "\n$(date) 正在运行  ales1_club_lottery.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales1'/" ales1_club_lottery.js
node ales1_club_lottery.js

printf "\n$(date) 正在运行  ba_club_lottery.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ba'/" ba_club_lottery.js
node ba_club_lottery.js

printf "\n$(date) 正在运行  qiu_club_lottery.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/qiu'/" qiu_club_lottery.js
node qiu_club_lottery.js

printf "\n$(date) 正在运行  ma_club_lottery.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ma'/" ma_club_lottery.js
node ma_club_lottery.js

rm `ls *_club_lottery.js | grep -v jd_club_lottery.js`

###

cp jd_redPacket.js sha_redPacket.js
cp jd_redPacket.js ales33_redPacket.js
cp jd_redPacket.js ales1_redPacket.js
cp jd_redPacket.js ba_redPacket.js
cp jd_redPacket.js qiu_redPacket.js
cp jd_redPacket.js ma_redPacket.js

printf "\n$(date) 正在运行  sha_redPacket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/sha'/" sha_redPacket.js
node sha_redPacket.js

printf "\n$(date) 正在运行  ales33_redPacket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales33'/" ales33_redPacket.js
node ales33_redPacket.js

printf "\n$(date) 正在运行  ales1_redPacket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales1'/" ales1_redPacket.js
node ales1_redPacket.js

printf "\n$(date) 正在运行  ba_redPacket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ba'/" ba_redPacket.js
node ba_redPacket.js

printf "\n$(date) 正在运行  qiu_redPacket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/qiu'/" qiu_redPacket.js
node qiu_redPacket.js

printf "\n$(date) 正在运行  ma_redPacket.js\n"
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ma'/" ma_redPacket.js
node ma_redPacket.js

rm `ls *_redPacket.js | grep -v jd_redPacket.js`
