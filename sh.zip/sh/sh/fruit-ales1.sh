#!/bin/bash
sleep $(shuf -i 7-300 -n 1)
cd /root/sp/js/
printf "\n$(date) 正在运行 ales1_fruit2.js\n"
#ales1
a0='0e969868fba541d3ab5546843580e26f'
#ales33
a='059d94201e934da286f7c79873ee11f3'
#sha
b='4590131d341e424d8fe46e70e5f3e9bf'
#ba
c='4e744665d2e044bc916281c147278ca9'
#ma
d='95cf055827d74110a77dbc11f9b7de2a'
#qiu
e='e800fc0989f84892bc64774e83b97270'
cp jd_fruit.js ales1_fruit2.js
sed -i "s/let jdFruitBeanCard = false/let jdFruitBeanCard = true/" ales1_fruit2.js
sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/ales1'/" ales1_fruit2.js
sed -i "/^let FruitShareCodes = /,/^]$/clet FruitShareCodes = [ \n'$b@$c@$d@$e',\n]" jdFruitShareCodes.js 
sed -i "/^    await doTenWater/c\/\/ " ales1_fruit2.js
sed -i "/^    await doTenWaterAgain/c\/\/ " ales1_fruit2.js
sed -i "s#http://api.turinglabs.net/api/v1/jd/farm/read/\${randomCount\}/#https\://raw.githubusercontent.com/ktownag/JDtmp/main/farm\.json#"  ales1_fruit2.js
node ales1_fruit2.js

