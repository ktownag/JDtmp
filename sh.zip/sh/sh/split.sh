#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_split.js -O /root/sp/js/jd_split.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jd_split.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" jd_split.js
sed -i "/^$.newShareCodes = \[/c\\$\.newShareCodes = [`P04z54XCjVUnIaW5m9cZ2Wqj3wenGne_TnOyVU`, 'P04z54XCjVUnIaW5jwI3cRYCfDwQ-j-', 'P04z54XCjVUnIaW5m9cZ2T-3CkYxFjIdct8C1w', 'P04z54XCjVUnIaW5jcBC2j833xKkmvVh4PKSpE', 'P04z54XCjVUnIaW5mRUXSP73g', 'P04z54XCjVUnIaW5mRUXSP5']\;"  jd_split.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_split.js ${i}_split.js
  printf "\n$(date) 正在运行  ${i}_split.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_split.js
  node ${i}_split.js
  rm ${i}_split.js
done
