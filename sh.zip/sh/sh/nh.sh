#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_nh.js -O /root/sp/js/jd_nh.js
#sleep $(shuf -i 8-400 -n 1)
cd /root/sp/js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  printf "\n$(date) 正在运行  ${i}_nh.js\n"
  sed -e "s/turinglabs/xxxx/g;
    s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/;
    s/chiang.fun/xxxxxx/g;
    s/updateTeam/xxxxxx/g;
    s/let shareUuid = /let shareUuid = \'35ec4da8e3074d1a8e4c951af2eb35e1\' \/\//g;
     /^let shareCodes = /,/^]$/c\let shareCodes = ['']; 
     /^let inviteCodes = /,/^]$/c\let inviteCodes = ['']; 
      /^const inviteCodes = /,/^]$/c\const inviteCodes = [\`\`,\n\`\`\n];
      s/28a699ac78d74aa3b31f7103597f8927//g" jd_nh.js | node
#  sleep $(shuf -i 1-9 -n 1)
done
