#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_health.js -O /root/sp/js/jd_health.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jd_health.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" jd_health.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_health.js ${i}_health.js
  printf "\n$(date) 正在运行  ${i}_health.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_health.js
  node ${i}_health.js
  rm ${i}_health.js
done
