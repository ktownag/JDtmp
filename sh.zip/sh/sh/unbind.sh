#!/bin/bash
wget https://gitee.com/lxk0301/jd_scripts/raw/master/jd_unbind.js -O /root/sp/js/jd_unbind.js
sleep $(shuf -i 8-400 -n 1)

cd /root/sp/js
sed -i "s/turinglabs/xxxx/g" jd_unbind.js
sed -i "/^const inviteCodes = /c\const inviteCodes = [''];" jd_unbind.js

acc=($(shuf -e "sha" "ales33" "xiaohao" "wzqru" "ales1" "ba" "qiu" "ma"))
for i in ${acc[@]}
do
  cp jd_unbind.js ${i}_unbind.js
  printf "\n$(date) 正在运行  ${i}_unbind.js\n"
  sed -i "s/'.\/jdCookie.js'/'\/root\/sp\/cki\/${i}'/" ${i}_unbind.js
  node ${i}_unbind.js
  rm ${i}_unbind.js
done
