#!/bin/bash

cd /root/sp/js
cp 818GetSC.js tmp.js
sed -i "s/ales1/sha/" tmp.js
node tmp.js
mv 818SC/818SCache.txt 818SC/sha

cp 818GetSC.js tmp.js
sed -i "s/ales1/ales33/" tmp.js
node tmp.js
mv 818SC/818SCache.txt 818SC/ales33

cp 818GetSC.js tmp.js
sed -i "s/ales1/qiu/" tmp.js
node tmp.js
mv 818SC/818SCache.txt 818SC/qiu

cp 818GetSC.js tmp.js
sed -i "s/ales1/ba/" tmp.js
node tmp.js
mv 818SC/818SCache.txt 818SC/ba

cp 818GetSC.js tmp.js
sed -i "s/ales1/ma/" tmp.js
node tmp.js
mv 818SC/818SCache.txt 818SC/ma

cp 818GetSC.js tmp.js
sed -i "s/ales1/sha/" tmp.js
node tmp.js
mv 818SC/818SCache.txt 818SC/ales1

cp jd_818-2.js jd_818_run.js
sed -i "s/aaaaaa/$(cat 818SC/sha)/" jd_818_run.js
sed -i "s/bbbbbb/$(cat 818SC/ales33)/" jd_818_run.js
sed -i "s/cccccc/$(cat 818SC/qiu)/" jd_818_run.js
sed -i "s/dddddd/$(cat 818SC/ba)/" jd_818_run.js
sed -i "s/eeeeee/$(cat 818SC/ma)/" jd_818_run.js
node jd_818_run.js

cp jd_818_run.js jd_818_run2.js
sed -i "s/ales1/sha/" jd_818_run2.js
node jd_818_run2.js

cp jd_818_run.js jd_818_run2.js
sed -i "s/ales1/ales33/" jd_818_run2.js
node jd_818_run2.js

cp jd_818_run.js jd_818_run2.js
sed -i "s/ales1/qiu/" jd_818_run2.js
node jd_818_run2.js

cp jd_818_run.js jd_818_run2.js
sed -i "s/ales1/ba/" jd_818_run2.js
node jd_818_run2.js

cp jd_818_run.js jd_818_run2.js
sed -i "s/ales1/ma/" jd_818_run2.js
node jd_818_run2.js

